//package com.example.tracknote.Models;
//
//public class User {
//    private String FirstName,LastName,PassWord,PhoneNumber;
//
//    public User(){}
//
//    public User(String firstName, String lastName, String passWord, String phoneNumber) {
//        FirstName = firstName;
//        LastName = lastName;
//        PassWord = passWord;
//        PhoneNumber = phoneNumber;
//    }
//
//    public String getFirstName() {
//        return FirstName;
//    }
//
//    public void setFirstName(String firstName) {
//        FirstName = firstName;
//    }
//
//    public String getLastName() {
//        return LastName;
//    }
//
//    public void setLastName(String lastName) {
//        LastName = lastName;
//    }
//
//    public String getPassWord() {
//        return PassWord;
//    }
//
//    public void setPassWord(String passWord) {
//        PassWord = passWord;
//    }
//
//    public String getPhoneNumber() {
//        return PhoneNumber;
//    }
//
//    public void setPhoneNumber(String phoneNumber) {
//        PhoneNumber = phoneNumber;
//    }
//}
