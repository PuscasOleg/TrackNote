package com.example.tracknote;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.annotations.NotNull;


import static com.example.tracknote.R.id.bntSignUp;

public class SignUpActivity extends AppCompatActivity {


      Button signUp;
      EditText lastName,firstName,password,email;
      FirebaseAuth auth;
      FirebaseDatabase db;
      DatabaseReference users;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        signUp=findViewById(R.id.bntSignUp);
        firstName=findViewById(R.id.FirstNameText);
        lastName=findViewById(R.id.LastNameText);
        password=findViewById(R.id.NewPasswordText);
        email=findViewById(R.id.Emailtext);
        auth=FirebaseAuth.getInstance();


        //Регистрация пользователя

        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 CreateUser();
            }
        });
    }

    private void CreateUser() {

        String userFirstName=firstName.getText().toString();
        String userLastName=lastName.getText().toString();
        String userPassword=password.getText().toString();
        String userEmail=email.getText().toString();
        if(TextUtils.isEmpty((CharSequence) firstName)){
            Toast.makeText(this,"Name is Empty!",Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty((CharSequence) lastName)){
            Toast.makeText(this,"Last Name is Empty!",Toast.LENGTH_SHORT).show();
            return;

        }
        if(userPassword.length()<6){
            Toast.makeText(this,"Password  Length must be greater then 6 letter!",Toast.LENGTH_SHORT).show();
            return;
        }


        auth.createUserWithEmailAndPassword(userEmail,userPassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull @NotNull Task<AuthResult> task) {

                if(task.isSuccessful()){
                    Toast.makeText(SignUpActivity.this,"Registration Successful",Toast.LENGTH_SHORT).show();

                }else{
                    Toast.makeText(SignUpActivity.this,"Error"+task.getException(),Toast.LENGTH_SHORT).show();
                }



            }
        });


    }

    public  void OpenSignIn(View view){
        Intent SingIn=new Intent(SignUpActivity.this,SignInActivity.class);
        startActivity(SingIn);
    }
}