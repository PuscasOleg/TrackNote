package com.example.tracknote;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class SignInActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
    }

    public  void OpenSignUp(View view){
        Intent SingUp=new Intent(SignInActivity.this,SignUpActivity.class);
        startActivity(SingUp);
    }

    public  void OpenForgotPassword(View view){
        Intent ForgotPassword=new Intent(SignInActivity.this,ForgotPasswordActivity.class);
        startActivity(ForgotPassword);
    }



};

